import configparser

def get_config(fn):
    conf = configparser.ConfigParser()
    conf.read(fn)
    return conf

def create_dsn(d):
    dsn = 'postgres://'

    # only add username:password if username and password exists in config
    dsn += f'{d["username"]}:{d["password"]}@' if 'username' in d and 'password' in d else  ''

    # only add host if host and password exist in config
    dsn += f'{d["host"]}' if 'host' in d and 'password' in d else ''

    # always add database name
    dsn += f'/{d["database"]}'

    return dsn

if __name__ == '__main__':
    import unittest
    class TestConfigModule(unittest.TestCase):
        def setUp(self):
            self.d = {'host': 'localhost', 'database': 'dbname'}

        def test_create_dsn_with_host_and_database(self):
            self.assertEqual(create_dsn(self.d), 'postgres:///dbname')

        def test_create_dsn_with_username_and_password(self):
            self.d['username'] = 'testuser'
            self.d['password'] = 'testpw'
            self.assertEqual(create_dsn(self.d), 'postgres://testuser:testpw@localhost/dbname')

    unittest.main()
