# columns and their types, including fk relationships
from sqlalchemy import Column, Integer, String, Date, Boolean
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship

# declarative base 
from sqlalchemy.ext.declarative import declarative_base

# create the base class (declarative base)
# call it Base!
Base = declarative_base()

# TODO: finish the implementation of two classes: 
# * ScooterType
# * Scooter
class Scooter(Base):
    # TODO: "link" to an actual table name!

    # TODO: scooter_id, acquired_date, retired, 
    
    # TODO: create a foreign key called scooter_type_id
    
    # TODO: create a relationship called scooter_type

    def __repr__(self):
        # TODO: implement this method
    
    def __str__(self):
        return self.__repr__() 

    
    def to_dict(self):
        d = {
            "acquired_date": self.acquired_date.strftime('%Y-%m-%d'),
            "retired": self.retired,
            "scooter_type": self.scooter_type.model,
            "max_speed": self.scooter_type.max_speed,
            "weight": self.scooter_type.weight,
            "manufacturer": self.scooter_type.manufacturer.name,
            "website": self.scooter_type.manufacturer.website
        }
        return d


class ScooterType(Base):
    # TODO: "link" to an actual table name!
    
    # TODO: scooter_type_id, model, max_range, weight, max_speed,
    
    # TODO create a foreign key called company_id!

    # TODO create a relationship called manufacturer

    def __repr__(self):
        # TODO: implement this method
        return f'{self.manufacturer.name} - {self.model}: {self.max_speed}km/hr and {self.weight}kg'
    
    def __str__(self):
        return self.__repr__() 

class Company(Base):
    __tablename__ = 'company'

    company_id = Column('company_id', Integer, primary_key=True)
    name = Column('name', String)
    website = Column('website', String)
    founded = Column('founded', Integer)

    scooter_types = relationship("ScooterType", back_populates="manufacturer")

    def __repr__(self):
        return f'{self.name}, ({self.website}), founded {self.founded}'
    
    def __str__(self):
        return self.__repr__() 

