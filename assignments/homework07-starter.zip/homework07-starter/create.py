from sqlalchemy.orm import sessionmaker
import db
import model

Session = sessionmaker(db.engine)
session = Session()

print('Creating tables...')
print('Using engine object: ', db.engine)
result = model.Base.metadata.create_all(db.engine)
