from sqlalchemy.orm import sessionmaker
import db
from model import Company, ScooterType, Scooter, Base
from datetime import datetime
import random

Session = sessionmaker(db.engine)
session = Session()


# TODO generate some data and insert it
# it may be helpful to create companies first, followed by types... then finally scooters

# TODO: remember to add to session and commit
# session.add_all(your_list_of_scooters)
# session.commit()
