# MongoDB Queries and Output
